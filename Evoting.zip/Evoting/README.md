BLOGBUAGABAGI


Installation

1. Download the source code using the Download button below.

2. Extract the downloaded file to your localhost folder ex. htdocs for XAMMP.

3. Import the included .sql file located in db folder which is the database of the system. If you have no idea on how to import, please refer to my tutorial on How import .sql file to restore MySQL database.

4. After a successful import, open the extracted folder and open conn.php in both the includes folder and in adminincludes folder. Edit the database name in the connection depending on the name of database you created in importing the included .sql file.

How to Use

1. First login as administrator by adding admin in the url. You should be redirected to admin login page.

Use this admin credential

Username admin
Password admin

2. Add the important data such as positions, candidates and voters.

3. Change the title of the election by clicking Election Title menu.

4. Rearrange the order of positions depending on the desired order to show in the ballot using Ballot Position menu.

That's it. Get the voters id of the added voters to be used to login to vote in the system. Voters id is name-SV-5 characters number long.