<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; <a href="https://www.instagram.com/">Kriis Sopian</a></strong>
</footer>